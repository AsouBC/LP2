public class LerArq {
    //Faltou ler o arquivo
}
