package REVERSI;

public enum Estado{VAZIO, PRETO, BRANCO}