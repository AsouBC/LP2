import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

//Fórmula: C -> C = (c*9)/5 + 32 = F
//Buguei, farei depois em casa

public class CelsiusToFahrenheit extends JFrame {

	private JLabel jlabel;
    public int fahrenheit;
	protected JTextField jtext;
	private JButton jbutton;

	public CelsiusToFahrenheit(String titulo) {
		super(titulo);
		setLayout(new FlowLayout());

		jlabel = new JLabel("Celsius:");
		jtext = new JTextField("0");
		jbutton = new JButton("Convert");

		add(jlabel);
		add(jtext);
		add(jbutton);

		TextFieldHandler handler = new TextFieldHandler();

		jtext.addActionListener(handler);
		jbutton.addActionListener(handler);

	}

	private class TextFieldHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			
			if (event.getSource()==jtext) {
				JOptionPane.showMessageDialog(CelsiusToFahrenheit.this,
						"Celsius: " + event.getActionCommand());
			} else {
				
				JOptionPane.showMessageDialog(CelsiusToFahrenheit.this,
						"Botão: " + CelsiusToFahrenheit.this.jtext.getText());
			}
			
		}

	}
	
	public static void main(String[] args) {
		CelsiusToFahrenheit my = new CelsiusToFahrenheit("Converter");
		my.setSize(300,130);
		my.setVisible(true);
	}

}
