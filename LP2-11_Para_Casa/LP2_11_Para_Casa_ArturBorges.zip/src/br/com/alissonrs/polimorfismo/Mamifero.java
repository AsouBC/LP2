package br.com.alissonrs.polimorfismo;

public abstract class Mamifero extends Animal {
	public abstract void mamar();
	//System.out.println("xuc, xuc, xuc");
	public abstract void correr();
}