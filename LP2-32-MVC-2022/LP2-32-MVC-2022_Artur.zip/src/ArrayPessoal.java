import java.util.ArrayList;

import model.Pessoal;

public interface ArrayPessoal{
    public ArrayList<Pessoal> getAllPessoa();
}