
import javax.swing.JApplet;

import java.applet.*;
import java.awt.Graphics;

public class MyApplet extends Applet {

     public void paint(Graphics g) {
     g.drawString("Oi gente!!!", 50, 25);

}
}