import java.util.Scanner;

public class Exercicio1{
    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        
        System.out.println("Numero inteiro de 5 digitos: ");
        int x = ler.nextInt();
        
        if(x >= 10000 && x < 100000){
            System.out.println("Numero dividido: " + x/10000);
            x = x%10000;
            
            System.out.println("Numero dividido: " + x/1000);
            x = x%1000;
            
            System.out.println("Numero dividido: " + x/100);
            x = x%100;
            
            System.out.println("Numero dividido: " + x/10);
            x = x%10;
            
            System.out.println("Numero dividido: " + x);
        }
    }
}