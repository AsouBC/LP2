public class Exercicio2{
    public static void main(String[] args) {
       System.out.print("Numero:  Quadrado:  Cubo:  \n");
       for(int i = 0; i <= 10; i++){
           System.out.println(i + "\t\t" + i*i + "\t\t\t" + i*i*i);
       }
    }
}