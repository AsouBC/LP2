import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.event.*;
import java.util.*;
import java.io.*;

public class Jogo{

    public Jogo() {
        JogoPainel jogoPainel = new JogoPainel();

        JFrame janela = new JFrame("Jogo");
        janela.add(jogoPainel);
        janela.pack();
        janela.setSize(640,480);
        janela.setResizable(false);
        janela.setVisible(true);
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JFrame botoes = new JFrame("Controles");
        JButton load = new JButton("Load");
        load.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Vector<Movel> bolas = new Vector<>();
                File file = new File("moveis.txt");
                try{
                    Scanner scanner = new Scanner(file);
                    scanner.nextLine();
                    while(scanner.hasNextLine()){
                        String[] line = scanner.nextLine().split(";");
                        if(Integer.parseInt(line[6]) == 0){
                            bolas.add(new Movel(Integer.parseInt(line[0]), Integer.parseInt(line[1]), Integer.parseInt(line[2]), Integer.parseInt(line[3]), Integer.parseInt(line[4]), Integer.parseInt(line[5])));
                        }else{
                            bolas.add(new Quadrado(Integer.parseInt(line[0]), Integer.parseInt(line[1]), Integer.parseInt(line[2]), Integer.parseInt(line[3]), Integer.parseInt(line[4]), Integer.parseInt(line[5])));
                        }
                    }
                    scanner.close();
                }catch(FileNotFoundException ex){
                    System.out.println("File not found");
                }
                jogoPainel.setBolas(bolas);
            }
        });
        JButton save = new JButton("Save");
        save.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Vector<Movel> moveis = jogoPainel.getBolas();
                File file = new File("moveis.txt");
                try {
                    PrintWriter writer = new PrintWriter(file);
                    writer.println("x;y;diametroForma;ColorRangeRed;ColorRangeGreen;ColorRangeBlue;indentificador");
                    for (Movel movel : moveis) {
                        writer.println(movel);
                    }
                    writer.close();
                }catch(FileNotFoundException e1){
                    e1.printStackTrace();
                }
            }
        });
        JButton adicionar = new JButton("Adicionar Bola");
        adicionar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jogoPainel.addBola();
            }
        });
        JButton adicionarQuad = new JButton("Adicionar Quadrado");
        adicionarQuad.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jogoPainel.addQuadrado();
            }
        });
        JButton remover = new JButton("Remover Objeto");
        remover.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jogoPainel.remove();
            }
        });
        JButton removerTudo = new JButton("Remover Tudo");
        removerTudo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jogoPainel.removeTudo();
            }
        });
        botoes.setLayout(null);
        load.setBounds(0, 0, 200, 100);
        save.setBounds(200, 0, 200, 100);
        adicionar.setBounds(0, 100, 200, 100);
        adicionarQuad.setBounds(200, 100, 200, 100);
        remover.setBounds(0, 200, 200, 100);
        removerTudo.setBounds(200, 200, 200, 100);
        botoes.add(save);
        botoes.add(load);
        botoes.add(remover);
        botoes.add(adicionar);
        botoes.add(adicionarQuad);
        botoes.add(removerTudo);
        botoes.pack();
        botoes.setSize(400, 330);
        botoes.setResizable(false);
        botoes.setVisible(true);
        botoes.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public static void main(String[] args){
        new Jogo();
    }
}
