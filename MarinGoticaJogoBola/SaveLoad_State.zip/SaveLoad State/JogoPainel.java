import java.awt.*;
import javax.swing.*;
import java.util.*;

public class JogoPainel extends JPanel implements Runnable {
    private Thread animacao;
    private int tempoEspera = 10;
    private boolean jogando = false;
    private Vector<Movel> moveis = new Vector<Movel>();

    public JogoPainel() {
        setBackground(Color.BLACK);
        setFocusable(true);
    }

    public void addNotify() {
        super.addNotify();
        iniciarJogo();
    }

    public void iniciarJogo() {
        if (animacao == null || !jogando) {
            animacao = new Thread(this);
            animacao.start();
        }
    }

    public void run() {
        jogando = true;
        while (jogando) {
            for(Movel movel: moveis){
                movel.move();
            }
            repaint();

            try {
                Thread.sleep(tempoEspera);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.exit(0);
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.WHITE);
        for (Movel bola : moveis) {
            bola.paintComponent(g);
        }
    }

    public Vector<Movel> getBolas() {
        return moveis;
    }

    public void setBolas(Vector<Movel> bolas) {
        this.moveis = bolas;
    }

    public void addBola() {
        Random random = new Random();
        int red = random.nextInt(256);
        int green = random.nextInt(256);
        int blue = random.nextInt(256);
        Movel bola = new Movel(random.nextInt(600), random.nextInt(400), random.nextInt(100), red, green, blue);
        moveis.add(bola);
    }

    public void addQuadrado(){
        Random random = new Random();
        int red = random.nextInt(256);
        int green = random.nextInt(256);
        int blue = random.nextInt(256);
        Quadrado quad = new Quadrado(random.nextInt(600), random.nextInt(400), random.nextInt(100), red, green, blue);
        moveis.add(quad);
    }

    public void remove() {
        if (moveis.size() > 0) {
            moveis.remove(0);
        }
    }

    public void removeTudo() {
        moveis.clear();
    }
}

class Movel {
    protected static final int LARGURA = 625, ALTURA = 445;
    protected int diametroBola = 30;
    protected int x = 50, y = 150;
    protected int velocidadeX, velocidadeY;
    protected Color color;
    protected int identificador = 0;

    public void move() {
        x += velocidadeX;
        y += velocidadeY;
        if (x >= LARGURA - diametroBola) {
            velocidadeX *= -1;
        }
        if (x <= 0) {
            velocidadeX *= -1;
        }
        if (y >= ALTURA - diametroBola) {
            velocidadeY *= -1;
        }
        if (y <= 0) {
            velocidadeY *= -1;
        }
    }

    public void paintComponent(Graphics g) {
        g.setColor(color);
        g.fillOval(x, y, diametroBola, diametroBola);
    }

    public Movel(int x, int y, int diametroBola, int R, int G, int B) {
        this.x = x;
        this.y = y;
        this.diametroBola = diametroBola;
        this.color = new Color(R, G, B);
        Random random = new Random();
        if (random.nextInt(2) == 0) {
            this.velocidadeX = -5;
        } else {
            this.velocidadeX = 5;
        }
        if (random.nextInt(2) == 0) {
            this.velocidadeY = -5;
        } else {
            this.velocidadeY = 5;
        }
    }

    @Override
    public String toString() {
        return x + ";" + y + ";" + diametroBola + ";" + color.getRed() + ";" + color.getGreen() + ";" + color.getBlue() + ";" + identificador;
    }
}

class Quadrado extends Movel{
    private int lado;
    private int identificador = 1;

    public Quadrado(int x, int y, int lado, int R, int G, int B) {
        super(x, y, lado, R, G, B);
        this.lado = lado;
        this.x = x;
        this.y = y;
        this.color = new Color(R, G, B);
        Random random = new Random();
        if (random.nextInt(2) == 0) {
            this.velocidadeX = -5;
        } else {
            this.velocidadeX = 5;
        }
        if (random.nextInt(2) == 0) {
            this.velocidadeY = -5;
        } else {
            this.velocidadeY = 5;
        }
    }

    public void paintComponent(Graphics g) {
        g.setColor(color);
        g.fillRect(x, y, lado, lado);
    }

    @Override
    public String toString() {
        return x + ";" + y + ";" + lado + ";" + color.getRed() + ";" + color.getGreen() + ";" + color.getBlue() + ";" + identificador;
    }
}