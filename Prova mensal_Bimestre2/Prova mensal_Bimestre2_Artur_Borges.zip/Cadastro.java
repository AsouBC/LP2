import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
/***
 * Classe com escutador externo
 */

 /*Eu buguei nessa prova professor. Me desculpe porém enviarei só o que consegui fazer. Estudarei mais e melhorei com certeza
 Não desista de mim, tentei meu melhor sobre pressão voltarei melhor :)
 */
public class Cadastro extends JFrame {

	//Define componentes da janela.
	private JLabel jLabelNumero;
	private JLabel jLabelNome;
	private JLabel jLabelGrupo;

	protected JTextField jtextNumero;
	protected JTextField jtextNome;
	protected JTextField jtextGrupo;

	private JButton jbuttonBuscar;
	
	
	public Cadastro(String titulo) {
		super(titulo);

		setLayout(new FlowLayout(FlowLayout.RIGHT));

		//Inicializa componentes da janela.
		jLabelNumero = new JLabel("Buscar" );		
		jLabelNome = new JLabel("Nome" );		
		jLabelGrupo = new JLabel("Grupo");
		
		jtextNumero = new JTextField("0",10);
		jtextNome = new JTextField(10);
		jtextGrupo = new JTextField(10);

		jbuttonBuscar = new JButton("Buscar");
		jbuttonBuscar.setPreferredSize(new Dimension(180,18));
		


		//Adiciona componentes na janela.
		this.add(jLabelNumero);		
		this.add(jtextNumero);
		this.add(jbuttonBuscar);

		this.add(jLabelNome);		
		this.add(jtextNome);

		this.add(jLabelGrupo);
		this.add(jtextGrupo);
				
		
		

		//Cria o escutador
		Escutador handler = new Escutador();

		//Adiciona o escutador a cada botão.
		jbuttonBuscar.addActionListener(handler);

		
			
	}

	private class Escutador implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			Int x;
				
				//jtextNome.setText("Buscar Nome em  " + jtextNumero.getText());
				
			try{ //Não consegui nada além de ler o arquivo, sorry.
				File arquivo = new File("dados.csv");
				Scanner sc = new Scanner(arquivo);
				while(sc.hasNextLine()){
					String[] palavras = sc.nextLine().split("[ ,]");
					x = Integer.parseInt(palavras[0]);
					if(x.equals(jtextNumero.getText())){
						jtextNome.setText(jtextNumero.getText());
					}
				}
					
				}catch(FileNotFoundException e){
					System.out.println(e.getMessage());
				}
			
			
		}

	}
	
	public static void main(String[] args) {
		Cadastro cadastro = new Cadastro("Cadastro");
		cadastro.pack();
		cadastro.setSize(210,150);
		cadastro.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cadastro.setVisible(true);
	}

}


