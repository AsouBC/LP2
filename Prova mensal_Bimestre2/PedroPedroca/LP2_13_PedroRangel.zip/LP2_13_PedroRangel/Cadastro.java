
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JOptionPane;

/***
 * Classe com escutador externo
 */
public class Cadastro extends JFrame {

	// Define componentes da janela.
	private JLabel jLabelNumero;
	private JLabel jLabelNome;
	private JLabel jLabelGrupo;

	protected JTextField jtextNumero;
	protected JTextField jtextNome;
	protected JTextField jtextGrupo;

	private JButton jbuttonBuscar;
	protected lerDados ler;
	private ArrayList<Aluno> dados = new ArrayList<Aluno>();
	int i;

	public Cadastro(String titulo) {
		super(titulo);

		setLayout(new FlowLayout(FlowLayout.RIGHT));

		ler = new lerDados();
		dados = ler.Ler("dados.csv");

		// Inicializa componentes da janela.
		jLabelNumero = new JLabel("Buscar");
		jLabelNome = new JLabel("Nome");
		jLabelGrupo = new JLabel("Grupo");

		jtextNumero = new JTextField(dados.get(0).numero + "", 10);
		jtextNome = new JTextField(dados.get(0).nome, 10);
		jtextGrupo = new JTextField(dados.get(0).grupo + "", 10);

		jbuttonBuscar = new JButton("Buscar");
		jbuttonBuscar.setPreferredSize(new Dimension(180, 18));

		jtextNome.setEditable(false);
		jtextGrupo.setEditable(false);

		// Adiciona componentes na janela.
		this.add(jLabelNumero);
		this.add(jtextNumero);
		this.add(jbuttonBuscar);

		this.add(jLabelNome);
		this.add(jtextNome);

		this.add(jLabelGrupo);
		this.add(jtextGrupo);

		// Cria o escutador
		Escutador handler = new Escutador();

		// Adiciona o escutador a cada botão.
		jbuttonBuscar.addActionListener(handler);

	}

	private class Escutador implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {

			i = Integer.parseInt(jtextNumero.getText()) - 1;

			if (i < 0) {
				JOptionPane.showMessageDialog(null, "Numero Inválido. Iremos mostrar o primeiro da lista");
				i = 0;
				jtextNumero.setText(dados.get(i).numero + "");
			} else if (i > dados.size() - 1) {
				i = dados.size() - 1;
				JOptionPane.showMessageDialog(null, "Numero Inválido. A lista apresenta " + dados.size()
						+ " alunos. Iremos mostrar o último da lista");
				jtextNumero.setText(dados.get(i).numero + "");
			}
			atualizar();
		}

		private void atualizar() {
			Aluno aluno = dados.get(i);
			jtextNome.setText(aluno.nome);
			jtextGrupo.setText(aluno.grupo + "");
		}
	}

	public static void main(String[] args) {
		Cadastro cadastro = new Cadastro("Cadastro");
		cadastro.pack();
		cadastro.setSize(210, 150);
		cadastro.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cadastro.setVisible(true);
	}

}
