public class Aluno {

    protected String nome;
    protected int grupo;
    protected int numero;

    public Aluno(int numero, String nome, int grupo) {
        this.nome = nome;
        this.grupo = grupo;
        this.numero = numero;
    }
}
