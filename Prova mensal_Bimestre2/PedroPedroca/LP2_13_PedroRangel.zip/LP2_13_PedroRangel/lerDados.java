import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;

public class lerDados {

    public ArrayList<Aluno> Ler(String Caminho) {
        ArrayList<Aluno> linhas = new ArrayList<Aluno>();

        try {
            Scanner ler = new Scanner(new File("dados.csv"));
            ler.nextLine();
            while (ler.hasNext()) {
                String v[] = ler.nextLine().split(",");
                linhas.add(new Aluno(Integer.parseInt(v[0]), v[1], Integer.parseInt(v[2])));
                // ou utilizar uma variável que receberá todos as linhas, exemplo: conteudo +=
                // linha;
            }
            ler.close();
        } catch (IOException ex) {
            System.out.println("Erro: Não foi possível ler o arquivo!");

        }
        return linhas;

    }
}
